export default {
    logLevel: 'info',
    apiVersion: '1.0.0',
    MESSAGE: 'hello',
}