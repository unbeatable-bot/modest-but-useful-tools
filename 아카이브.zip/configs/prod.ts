export default {
    logLevel: 'error',
    dbInfo: 'http://prod-:3306'
}