export default {
    dbInfo: 'http://localhost:3306',
}