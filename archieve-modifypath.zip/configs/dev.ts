export default {
    logLevel: 'debug',
    dbInfo: 'http://dev-mysql:3306',
}
